document.onkeypress = handleKeyPress;

function log(msg) {
    document.getElementById("log").innerHTML += msg + "\n";
}

function handleKeyPress(event) {
    console.log(event);
    log("meta: "+event.metaKey+
        ", alt: "+event.altKey+
        ", shift: "+event.shiftKey+
        ",\n\tkeyCode: "+event.keyCode+
        ", charCode: "+event.charCode+
        ", text: "+String.fromCharCode(event.charCode)
        );
    if (event.metaKey && ("+" === String.fromCharCode(event.charCode))) {
        log('COMMAND +');
    }
    return false;
}
